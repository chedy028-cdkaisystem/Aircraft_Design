# Heart Aerospace X1: parametric geometry + AVL/range ESTIMATES

**Read this first.** Heart has not published CAD for the X1. This model combines a few published numbers with
dimensions **estimated from public photos**, and fills the rest with **engineering assumptions** (airfoils, CG,
inertias, control-surface sizes, cruise condition). Every result below is a low-order *estimate*, not Heart data.
Variants B and C are hypothetical configurations. They do not exist on the real aircraft.

Built 2026-10-18 on the box. OpenVSP 3.55.0 (Ubuntu 24.04 .deb extracted to /opt/OpenVSP), AVL 3.52 (compiled
from MIT source, binary at `tools/avl`), Octave 9.4.

## Files
| path | what |
|---|---|
| `params.yaml` | **The single parameter file.** Each value is tagged `published` / `photo-est` / `assumption`, with uncertainty and source photo |
| `x1_gen.py` | generator: params -> AVL decks + mass files, OpenVSP script -> `.vsp3`, watertight STL, STEP, CD0 buildup |
| `analyze.py` | runs AVL for A/B/C under 2 CG modes: trim, stability derivatives, eigenmodes, stall sweep, OEI, climb, foreplane-area sweep |
| `range.m` | MATLAB/Octave range estimate + sensitivity; reads `results/drag_<V>.txt` |
| `render_views.py` | 3-view PNGs from the STL, for checking against the photos |
| `high_alpha.py` | alpha −2…20° sweeps (trimmed + fixed deflection) with strip-saturation post-processing → `results/high_alpha_*` |
| `run_all.sh` | rebuilds everything |
| `vsp/x1_{A,B,C}.vsp3` (+ `.vspscript`) | OpenVSP models (open in the OpenVSP GUI; set "CFD" = surfaces exported to STL) |
| `cad/x1_{A,B,C}.stl` | watertight single-shell STL in metres (props excluded), checked with trimesh: watertight, 1 body |
| `cad/x1_{A,B,C}.step` | STEP surfaces from OpenVSP (untrimmed components) |
| `avl/x1_{A,B,C}.avl`, `.mass` | AVL decks (CG at 25% MAC) and lumped mass; `avl/work/` holds per-run decks, inputs and logs |
| `openfoam/` | `blockMeshDict`, `snappyHexMeshDict`, `surfaceFeatureExtractDict`, minimal `controlDict`/`fvSchemes`/`fvSolution`, STLs in `constant/triSurface`, `Allrun` (mesh only; no `0/` fields, no actuator disks) |
| `results/summary.md`, `summary.json` | all AVL / flight estimates |
| `results/drag_*.txt`, `range_octave_output.txt`, `x1_*_views.png`, `geometry_summary.json` | |
| `photos/` | 24 public X1 photos (1200 px) from heartaerospace.com used for the scaling |

Coordinates: x aft from the nose tip, y to starboard, z up from the ground. SI units.

## Variants
* **A**: baseline as built: strut-braced high wing, T-tail, 4 wing-mounted pods.
* **B**: Piaggio P.180-style three-surface: foreplane `area_B` = 3.5 m² at x = 4.2 m plus the HT shrunk to 60% area. The HT keeps the elevator; the foreplane is fixed at +2°.
* **C**: Musk's literal wording: a "small wing" foreplane replaces the horizontal stabilizer. `area_C` = 6 m², the foreplane carries the elevator, there is no HT, and the fin is kept.
Foreplane area, x-position, z, incidence, aspect ratio, taper and sweep are all parameters (`foreplane:` in params.yaml).

## Published vs estimated
**Published:** span 32.3 m (106 ft), length 23.2 m (76 ft), height 7.3 m (24 ft), MTOW ≈ 11,340 kg (25,000+ lb),
4 × 400 kW PMSM at 1,800 rpm, 2,100 N·m, 720 V, 4 × 90 kWh = 360 kWh, water-glycol cooling. High wing, T-tail.
Sources: heartaerospace.com/x1; first-flight PR (Aug 2026); J. Hellsing, SCSSS 2024 safety presentation.

**From the photos:** a strut-braced high wing (single strut per side, from the belly sponson to about y = 6.5 m); long slender pods roughly
centred on the wing chord plane with the props well ahead of the LE; a strongly swept fin; a T-tail; belly sponsons.

**Photo estimates** (each with its source photo in params.yaml). FRONT = `260725_..._2024Xx`, SIDE = `..._2045Xxx`, TOP = `..._2396X`.
Scaled off the published span (front view), length and height (side view). Perspective was corrected only roughly.
| item | value | ± | photo |
|---|---|---|---|
| wing root / tip chord | 2.5 / 1.25 m | 0.4 / 0.3 | TOP (oblique, heavy perspective) |
| → wing area, AR, MAC | 60.6 m², 17.2, 1.94 m | ~±15% area | derived |
| wing LE sweep / dihedral | ~1° / ~0.5° | 2° / 1.5° | TOP, FRONT |
| wing root LE x, chord-plane z | 8.6 m, 3.85 m | 0.7, 0.25 | SIDE, FRONT |
| nacelle stations y | 3.8 / 7.8 m | 0.4 / 0.5 | FRONT |
| nacelle length / dia; prop dia | 3.6 / 0.8 m; 2.0 m | 0.6 / 0.15; 0.3 | SIDE, FRONT |
| fuselage length / width / height | 20.8 / 2.3 / 2.35 m | 0.6 / 0.3 / 0.3 | SIDE, FRONT |
| fin height above root / root, tip chord / LE sweep | 3.85 m / 4.8, 2.1 m / 52° | 0.4 / 0.8, 0.4 / 8° | SIDE |
| HT span / root, tip chord / LE sweep | 8.0 m / 2.0, 1.0 m / 30° → 12 m² | 1.0 / 0.4, 0.3 / 8° | FRONT, TOP |
| gear: nose x, main x, track | 2.9, 10.1, 2.7 m | 0.4, 0.5, 0.4 | SIDE, FRONT |
| strut wing attachment y | 6.5 m | 0.5 | FRONT |
Closure check: the model's overall length is 22.9 m vs 23.2 m published, and its height is 7.37 m vs 7.3 m.

**Assumptions (not from photos):** NACA 4415/4412 wing, NACA 0012 tails, wing incidence 2°, aileron/elevator/rudder
chord fractions, section clmax (wing 1.6, foreplane 1.4), CG x at 25% MAC and z = 3.0 m, Roskam radii of gyration
(Ixx 1.85e5, Iyy 2.20e5, Izz 4.42e5 kg·m²), cruise 80 m/s at 3,000 m ISA (an assumed condition; Heart has not published it),
climb at 60 m/s at sea level, η_prop 0.80, battery 0.95, drive 0.93, usable energy fraction 0.80, failed-prop drag 10% of thrust.

## Results (ESTIMATES, from `results/summary.md`)
Cruise CL is 0.631 in every variant. "Same CG" means x_cg = 9.21 m (25% MAC). "SM15" means the CG is moved so the static margin is 15%.
| | A baseline | B 3-surface | C foreplane, no HT |
|---|---|---|---|
| Xnp | 10.49 m | 9.75 m | 8.89 m |
| static margin, same CG | 66% (unrealistically high, see issues) | 27% | **−17% (unstable)** |
| CDi trimmed, same CG / SM15 | 0.00774 / 0.00777 | 0.00795 / 0.00786 | 0.00824 / **0.01388** |
| trim deflection SM15 | +7.7° elevator | +4.8° | **+21° foreplane elevator** |
| L/D, same CG / SM15 | 21.3 / 21.3 | 21.5 / 21.6 | 22.0 / **18.4** |
| range (range.m), same CG / SM15 | 140 / 140 km | 142 / 142 km | 145 / **121 km** |
| short period (SM15) | ωn 1.57, ζ 0.68 | ωn 1.46, ζ 0.64 | ωn 1.19, ζ 0.55 (same CG: divergent, t₂ ≈ 1 s) |
| phugoid (SM15) | T 49 s, ζ 0.02 | T 45 s, ζ 0.005 | T 38 s, ζ −0.035 |
| dutch roll | ωn ≈ 1.1–1.2, ζ ≈ 0.13 | same | same |
| spiral | mildly unstable, t₂ ≈ 26 s | same | same |
| stall order (same CG) | wing first, CL 1.49 | **wing before foreplane** (1.55 vs 1.66): not canard-safe | wing first (1.56 vs 2.08): not canard-safe |
| stall order (SM15) | CL 1.62 | wing first (1.58 vs 1.70) | foreplane already at clmax at CL ≈ 0.60, so it cannot fly a usable CL range |
| ROC at MTOW, SL, 1.28 MW thrust power | ≈1,760 fpm | ≈1,765 | ≈1,650–1,780 |
| ROC with 3 motors | ≈1,180 fpm | ≈1,185 | ≈1,070–1,200 |
| outboard-motor-out yaw moment / rudder | ≈51–53 kN·m at 1.2 Vs (~52 m/s), 9–11° rudder (limit 25°) | 9–10° | 9.6° (same CG) |
Variant C foreplane-area sweep at SM15: going from 6 to 12 m² brings the trim deflection down from 21° to 15° and the foreplane cl from 1.23 to 0.88, but L/D stays near 18.3–18.5.

**Reading the results:**
1. The B layout (P.180-style) comes out about 1% better on L/D than A at the same static margin. That is within the noise of this method.
2. Musk's literal version (C) only improves L/D, by about 3–4%, when it is *statically unstable*, i.e. flown with active stability augmentation.
3. Make C stable (CG ahead of the NP) and the foreplane carries a heavy load at a high cl. Trim drag then grows sharply, and the foreplane, not the wing, limits CLmax.
4. A canard is stall-safe only when the foreplane stalls first. B with +2° foreplane incidence does not satisfy that. Raising `incidence_B` or lowering the foreplane clmax would.

Range sensitivity (range.m, variant A): L/D ±10% → ±10%, usable fraction 0.7/0.9 → −12.5%/+12.5%, η_prop ±0.05 → ±6%,
mass ±500 kg → about ∓4.5%, about 6.6 km per unit of L/D. range.m counts cruise only (no climb or reserves). An L/D around 21 is probably
**optimistic**: the CD0 of about 0.022 excludes landing-gear, cooling and excrescence drag beyond the 10% add-on.

## What still needs better photo-based estimation
* **Wing chord / area.** This is the biggest driver of every number. It was estimated only from an oblique drone shot. A true top or underside view, or an airport-diagram overflight, would help.
* **Wing x-position relative to the CG, and the real CG.** The fixed-CG static margin of 66% for A means either the HT is too big, the tail arm is too long, or the real CG sits well aft of 25% MAC. Battery location is unknown.
* **HT span and chord, fin sweep.** Taken from perspective-distorted views.
* **Nacelle vertical offset and length, prop diameter and blade count.**
* **Fuselage cross-section and nose/tail shape** (simple ellipses used). Sponson shape, strut section and attachment points.
* **Landing gear.** Positions only, with no geometry in the STL or drag. Whether it retracts is unknown; it is down in the flight photos.
* The media-bank zip (23 files) would add views. A head-on photo with a ruler or a profile at known range would greatly cut the error.

## Issues encountered
* The **media-bank zip could not be fetched headless.** `/api/download/zip` is a protected POST endpoint behind bot protection.
  I used the 24 individual 1200 px images on the public /x1 and /media-bank pages instead. Heart's terms say images
  "should be downloaded for each use and not stored locally" and are for editorial use with credit. Delete `photos/` if that matters.
* **OpenVSP:** pip has no wheel, and the official 26.04 and 24.04 .debs don't install on Debian 13 (glibc and libpython deps). The
  24.04 .deb, *extracted* to /opt/OpenVSP plus libcminpack1/libglew2.2, runs fine (`vspscript`). The bundled Python API
  needs Python 3.12, so the model is built through generated AngelScript (`vsp/*.vspscript`).
* The first STL had open edges: the fuselage aft end was uncapped and the fin root sat on the surface. Fixed with a flat end cap and by extending the fin root 0.5 m into the fuselage in the VSP/CFD geometry only.
* **AVL C1 gotcha:** setting density after velocity keeps CL and changes V. The scripts set d, then m, then v. AVL's control derivatives are per degree.
* AVL models no fuselage, nacelles or props (no BODY entries and no propwash), and it is linear: no viscous stall. Stall uses the critical-section method on assumed section clmax values.
* Octave warns that `range.m` shadows its built-in `range()`. Harmless.
* Not modelled: gimbaled-motor control in place of control surfaces, battery-as-structure, flaps, ground effect, propwash, compressibility beyond Prandtl-Glauert.
